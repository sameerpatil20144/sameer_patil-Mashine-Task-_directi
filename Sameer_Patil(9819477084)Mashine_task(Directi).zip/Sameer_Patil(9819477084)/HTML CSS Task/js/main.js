// Hide Your Code Inside Inspect Element Start
$(document).bind("contextmenu",function(e) {
 e.preventDefault();
});
// Hide Your Code Inside Inspect Element End

// Modal Box Start
function display_modal_box(){
    document.querySelector("#Mybox").style.display="block";    
    document.querySelector("#modal").style.display="block";
}
function cancel_modal_box(){
    document.querySelector("#Mybox").style.display="none";    
    document.querySelector("#modal").style.display="none";
}
// Modal Box End
